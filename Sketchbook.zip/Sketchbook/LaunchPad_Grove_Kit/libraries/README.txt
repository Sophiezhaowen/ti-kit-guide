If you wish to use these libraries please copy the folders into your Energia libraries folder. 
Windows: My Documents\Energia\libraries
Mac & Linux: ~/Documents/Energia/Libraries

Libraries installed in this folder will remain on your computer even when installing new versions of Energia IDE and the IDE will know to look in this folder automatically for new libraries. 

You will need to restart the Energia IDE for your library list to refresh. Once you reopen Energia you can view the example code stored in the library under File > Examples > [library name]